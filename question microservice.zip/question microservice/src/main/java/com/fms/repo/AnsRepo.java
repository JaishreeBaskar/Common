package com.fms.repo;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fms.model.Ans;
import com.fms.model.Answer;

import reactor.core.publisher.Mono;

@Repository
public interface AnsRepo extends ReactiveCrudRepository<Ans, Integer>{

	@Transactional
	@Query("UPDATE feedback.ans as a SET a.answer = :answer, a.event_id = :eventId, a.employee_id = :employeeId WHERE (a.ans_id = :ansId );"+"UPDATE feedback.qns as q SET q.question='hello' WHERE (q.qns_id=1)")
	
	Mono<Ans> addAns(@Param("ansId") Integer ansId,@Param("answer") String answer,@Param("eventId") Integer eventId,@Param("employeeId") Integer employeeId);
	
	

}
