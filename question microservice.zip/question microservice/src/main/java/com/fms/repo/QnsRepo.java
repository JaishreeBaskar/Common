package com.fms.repo;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;

import com.fms.model.Ans;
import com.fms.model.Answer;
import com.fms.model.Qns;

import reactor.core.publisher.Mono;

@Repository
public interface QnsRepo  extends ReactiveCrudRepository<Qns, Integer>{

	@Query("UPDATE feedback.qns SET count = (count+1) WHERE (qns_id = :qns_id)")
	Mono<Qns> updateCount(@Param("qns_id") Integer qnsId);
	
//	SELECT feedback.qns.*,(count(*) *(select COUNT(*)  where feedback.qns.qns_id=feedback.ans.ans_qns_id )) as count from feedback.qns left join feedback.ans on feedback.qns.qns_id=feedback.ans.ans_qns_id group by feedback.qns.qns_id;

}
