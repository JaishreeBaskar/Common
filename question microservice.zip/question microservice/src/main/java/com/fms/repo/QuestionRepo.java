package com.fms.repo;


import java.util.List;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.fms.model.Question;

import reactor.core.publisher.Flux;

@Component
@Repository
public interface QuestionRepo extends ReactiveCrudRepository<Question, Integer>{

	
	@Query("SELECT * FROM feedback.question where event_id =:eventId ")
	Flux<Question> findByeventId(Integer eventId);
//	@Query("SELECT * FROM feedback.question where event_id =:eventId ")
//	Flux<Question> qf(Integer q);
	@Query("SELECT * FROM feedback.question where (feedback_type = :feedbackType or :feedbackType IS NULL) and (question = :question or :question IS NULL) and (event_id = :eventid or :eventid IS NULL) ")
	Flux<Question> qf(@Param("feedbackType") String feedbackType,@Param("question") String question,@Param("eventid") Integer eventid);
	
	
		
//	@Query("SELECT new com.fms.model.EventSummary1(c.livesImpacted) FROM  com.fms.entity.EventSummary AS c")
//	//@Query("select count(*) as totalEvents ,sum(lives_impacted) as livesImpacted,sum(total_no_of_volunteers)as totalVolunteers ,sum(total_no_of_volunteers)as totalParticipants from eventsummary;")
//	public Mono<com.fms.model.EventSummary1> adminDashBoard();


}
