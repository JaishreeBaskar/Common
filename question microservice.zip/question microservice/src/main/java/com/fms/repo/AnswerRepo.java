package com.fms.repo;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;

import org.springframework.stereotype.Repository;
import com.fms.model.Answer;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;



@Repository
public interface AnswerRepo extends ReactiveCrudRepository<Answer, Integer>{

//	@Query("SELECT * FROM feedback.answer")
	@Query("SELECT * FROM answer where event_id = :eventid  ORDER BY employee_id")
	Flux<Answer> findByFilter(@Param("eventid") Integer eventId );
//	and (answer = :ans or :ans IS NULL) ,@Param("ans") String ans

	@Query("Select count(distinct  employee_id) from feedback.answer where (event_id = :eventid or :eventid IS NULL)")
	Mono<Long> findCount(@Param("eventid") Integer passEventId);
	@Query("SELECT feedback.answer.* FROM feedback.answer as answer Left JOIN feedback.question as question ON answer.question_id=question.question_id where answer.event_id = :eventid and question.feedback_type='participated'")
	Flux<Answer> mappingTest(@Param("eventid") Integer passEventId);

	@Query("SELECT * FROM feedback.answer")
	Flux<Answer> findAllans();

	@Query("UPDATE feedback.answer SET employee_id = (employee_id+1) WHERE (question_id = :question_id)")
	Mono<Answer> updateCount(@Param("question_id") int questionId);
	
	
}
