package com.fms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fms.model.Answer;
import com.fms.repo.AnswerRepo;

import reactor.core.publisher.Mono;

@Service
public class QuestionService {

	@Autowired
	AnswerRepo answerrepo;
	
	public void sample(Integer questionId) {
		// TODO Auto-generated method stub
		System.out.println("helloo"+questionId);
		answerrepo.updateCount(questionId).log();
	}
	


}
