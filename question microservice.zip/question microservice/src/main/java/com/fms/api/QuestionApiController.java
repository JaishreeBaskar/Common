package com.fms.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fms.model.Ans;
import com.fms.model.Answer;
import com.fms.model.Qns;
import com.fms.model.Question;
import com.fms.repo.AnsRepo;
import com.fms.repo.AnswerRepo;
import com.fms.repo.QnsRepo;
import com.fms.repo.QuestionRepo;
import com.fms.service.QuestionService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import java.util.List;
import java.util.Optional;
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2020-01-27T17:20:00.118+05:30[Asia/Calcutta]")
@RestController
public class QuestionApiController implements QuestionApi {

	@GetMapping("/hello")
	public String hello() {
		return "hello";
	}
	  @Autowired
      QuestionRepo questionrepo;
	  
	  @Autowired
	  AnswerRepo answerrepo;
	
	  @Autowired
	  QuestionService questionService;
      
      @GetMapping(value="/getq")
      public Flux<Question> findBooks(){
    	  
      	return questionrepo.findAll();
      }
      
      @GetMapping(value="/q/{id}")
      public Mono<Question> findBookById(@PathVariable Integer id) {
                      return questionrepo.findById(id);
      }
    
 
      @Override
    public Flux<Question> getQuestionListUsingGET(Integer eventId) {
    	// TODO Auto-generated method stub
//    	return QuestionApi.super.getQuestionListUsingGET(eventId);
    	  
//    	  return repo.findAll();
    	  return questionrepo.findByeventId(eventId);
    	  
    }
      
      @Override
    public Mono<Question> addQuestionUsingPOST(@Valid Question body) {
    	// TODO Auto-generated method stub
    	Integer questionId=body.getQuestionId();
    	System.out.println(questionId);
    	questionService.sample(questionId);
//  	Mono<Answer> aa=answerrepo.updateCount(questionId).log();
//    	System.out.println("aa= "+aa);
    	return questionrepo.save(body).log();
    }
      
      @GetMapping(value="/addcount/{questionId}") 
    	  public Mono<Answer> updateCount(@PathVariable Integer questionId) {
    		  return answerrepo.updateCount(questionId);
    	  }
    	  
      
      
      //filter question 
      @GetMapping(value="/filterquestion")
      public Flux<Question> filterQuestion(@RequestBody Question q){
    	  System.out.println(q);
    	  
    	  String feedbackType=q.getFeedbackType();
    	   String question=q.getQuestion();
    	    Integer questionId=q.getEventId();
    	    Integer eventId=q.getEventId();
    	    System.out.println("ft "+feedbackType+" qu "+question+" qid "+questionId+" eid "+eventId);
//    	    return questionrepo.findAll();
    	  return questionrepo.qf(feedbackType,question,eventId);
      }
      
      //All Answer Api
      @GetMapping(value="/getanswer")
      public Flux<Answer> findAnswer(){
      	return answerrepo.findAllans();
      }
      
      
      //Answer by event id
      @GetMapping(value="/answersby/{eventId}/{ans}")
      public Flux<Answer> filterAnswer(@PathVariable Integer eventId,@PathVariable String ans) {
    	  System.out.println(eventId+" "+ ans);
    	  String pass=null;
    	  System.out.println("before "+pass);
    	  if(!ans.equals("NULL"))
    		 pass=ans;
    	  System.out.println("ans "+pass);
    	  return answerrepo.findByFilter(eventId).log();
//    	  return answerrepo.findById(eventId);
      }
       
      
      @GetMapping(value="/count/{eventId}/{type}")
      public Mono<Long> countPeople(@PathVariable Integer eventId,@PathVariable String type) {
    	  System.out.println(eventId+" "+type);
    	  String passType=null;
    	  Integer passEventId=null;
    	  if(!type.equals("NULL"))
    		  passType=type;
    	  if(!(eventId==0))
    		  passEventId=eventId;
    		System.out.println(passEventId+" "+passType);  
		return answerrepo.findCount(passEventId);
		
		
	
    	  
      }
      
      
  	@GetMapping("/mappingTest")
	public Flux<Answer> mappingTest() {
		return answerrepo.mappingTest(1);
	}
  	
  	@Autowired
  	AnsRepo ansRepo;
  	@GetMapping("/ans")
  	public Flux<Ans> ansTesting() {
  		
  		int a=1;
  		if(a>0)
  		{
  			System.out.println("11");
  		}
  		return ansRepo.findAll();
  	}
  	@PostMapping("/ans")
  	public Mono<Ans> ansPostTesting(@RequestBody Ans a) {
  		
  		
  		if(a.getAnsId()==null)
  		{
  			System.out.println("null");
  		}
  		return ansRepo.save(a);
//  		return ansRepo.addAns(ans.getAnsId(),ans.getAnswer(),ans.getEventId(),ans.getEmployeeId());
  	}
  	
  	@Autowired
  	QnsRepo qnsRepo;
  	@GetMapping("/qns")
  	public Flux<Qns> qnsTesting() {
  		return qnsRepo.findAll();
  	}
  	
  	@GetMapping("/qns/{id}")
  	public Mono<Qns>getByid(@PathVariable Integer id){
  		return qnsRepo.findBy;
  	}
  	
	@PostMapping("/qns")
  	public Mono<Qns> qnsPostTesting(@RequestBody Qns q) {
		Integer id=q.getQnsId();
		if(id!=null)
		{
			System.out.println("not null");
			Mono<Qns> qt= qnsRepo.updateCount(id);
			
		}
			
  		return qnsRepo.updateCount(id);
  	}
}
