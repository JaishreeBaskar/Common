package com.fms.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Transient;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import com.fasterxml.jackson.annotation.JsonProperty;
@Entity
@Table("ans")
public class Ans {
	
	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	  @JsonProperty("ans_id")
	 @Column(name="ans_id")
	  private Integer ansId = null;
	 
	 @JsonProperty("answer")
	  @Column(name="answer")
	  private String answer = null;
	 
	 @JsonProperty("event_id")
	  @Column(name="event_id")
	  private Integer eventId = null;
	 
	 @JsonProperty("employee_id")
	  @Column(name="employee_id")
	  private Integer employeeId = null;
	 
	 
	 @JsonProperty("ans_qns_id")
	  @Column(name="ans_qns_id")
	  private Integer ansQnsId = null;
	 
//	 @Transient
//	 @ManyToOne
//	 @JoinColumn(name = "ans_qns_id")
//	    private Qns qns;

	public Integer getAnsId() {
		return ansId;
	}

	public void setAnsId(Integer ansId) {
		this.ansId = ansId;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public Integer getEventId() {
		return eventId;
	}

	public void setEventId(Integer eventId) {
		this.eventId = eventId;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	
	
//	public Qns getQns() {
//		return qns;
//	}
//
//	public void setQns(Qns qns) {
//		this.qns = qns;
//	}

	public Ans() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getAnsQnsId() {
		return ansQnsId;
	}

	public void setAnsQnsId(Integer ansQnsId) {
		this.ansQnsId = ansQnsId;
	}


	 

}
