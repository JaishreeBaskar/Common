package com.fms.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import com.fasterxml.jackson.annotation.JsonProperty;
@Entity
@Table("answer")
public class Answer {
	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	  @JsonProperty("answer_id")
	 @Column(name="answer_id")
	  private Integer answerId = null;

//  @JsonProperty("question_id")
// 
//  private Integer questionId = null;


  
	 
  @JsonProperty("answer")
  @Column(name="answer")
  private String answer = null;

  @JsonProperty("event_id")
  @Column(name="event_id")
  private Integer eventId = null;
  
  @JsonProperty("employee_id")
  @Column(name="employee_id")
  private Integer employeeId = null;

public Integer getAnswerId() {
	return answerId;
}

public void setAnswerId(Integer answerId) {
	this.answerId = answerId;
}

//public Integer getQuestionId() {
//	return questionId;
//}
//
//public void setQuestionId(Integer questionId) {
//	this.questionId = questionId;
//}



public String getAnswer() {
	return answer;
}

//public Question getQuestion() {
//	return question;
//}
//
//public void setQuestion(Question question) {
//	this.question = question;
//}

public void setAnswer(String answer) {
	this.answer = answer;
}

public Integer getEventId() {
	return eventId;
}

public void setEventId(Integer eventId) {
	this.eventId = eventId;
}



public Integer getEmployeeId() {
	return employeeId;
}

public void setEmployeeId(Integer employeeId) {
	this.employeeId = employeeId;
}

public Answer() {
	super();
	// TODO Auto-generated constructor stub
}
  
  
  

}
