package com.fms.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Transient;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table("qns")
public class Qns {
	
	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	  @JsonProperty("qns_id")
	 @Column(name="qns_id")
	  private Integer qnsId = null;
	
	 @JsonProperty("question")
	  @Column(name="question")
	  private String question = null;
	 
	 @JsonProperty("type")
	  @Column(name="type")
	  private String type = null;
	 
	 @JsonProperty("count")
	 @Column(name="count")
	  private Integer count = null;
	 
	 
//	 @Transient
//	 @OneToMany(mappedBy = "qns")
//	 private List<Ans> ans = new ArrayList<>();

	public Integer getQnsId() {
		return qnsId;
	}

	public void setQnsId(Integer qnsId) {
		this.qnsId = qnsId;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}
	

//	public List<Ans> getAns() {
//		return ans;
//	}
//
//	public void setAns(List<Ans> ans) {
//		this.ans = ans;
//	}
	 
	
	 

}
